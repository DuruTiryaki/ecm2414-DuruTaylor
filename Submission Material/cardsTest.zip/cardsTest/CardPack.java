import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class CardPack {
    private List<Card> cards;

    // Constructor
    public CardPack() {
        cards = new ArrayList<>();
    }

    // Getter, returns the list of cards in the pack
    public List<Card> getCards() {
        return cards;
    }

    // Shuffles cards
    public void shuffle() {
        Collections.shuffle(cards);
    }


    // Returns the remaining cards
    public int remainingCards() {
        return cards.size();
    }

    // Add card to the deck
    public void addCard(Card card) {
        cards.add(card);
    }
}