TEST SUITE INFORMATION:

Our tests utilise the JUnit 4.x framework.

We have included a Java program (in the form of a Jar executable), which will execute the test suite and output the results. The source code of this is available in the file RunAllTests.java.

To execute, run java -jar cardsTest.jar. The program will go through each test class, and output the results for each class.