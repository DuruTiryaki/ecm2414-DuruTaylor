public class Card {
    // Number of Card
    private final int value;

    // Constructor sets value of card
    public Card(int value) {
        this.value = value;
    }

    // Returns value of Card
    public int getValue() {
        return value;
    }
}
